<?php
    // $host = "localhost";
    // $login = "root";
    // $password = "";
    // $db = "id15199194_czasnamasaz";
    //header("Location: ../index.php");
    $host = "localhost";
    $login = "id15199194_admin";
    $password = "44PTcz-4pPmA2U*M";
    $db = "id15199194_czasnamasaz";
?>